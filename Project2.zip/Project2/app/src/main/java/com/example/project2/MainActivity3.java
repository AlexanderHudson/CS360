package com.example.project2;

import android.os.Bundle;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.project2.databinding.Activity3Binding;

public class MainActivity3 extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private Activity3Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    List<String> months = new ArrayList<String>();
    List<Integer> days = new ArrayList<Integer>();
    List<Integer> years = new ArrayList<Integer>();
    Scanner scnr = new Scanner(System.in);
    String description = scnr.nextLine();
    EditText dateDescription = (EditText)findViewById(R.id.dateDescription);

        Spinner dropdownMonth = findViewById(R.id.spinnerMonth);
        Spinner dropdownDay = findViewById(R.id.spinnerDay);
        Spinner dropdownYear = findViewById(R.id.spinnerYear);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, months);

        dropdownMonth.setAdapter(adapter);
    int day;
    int year;
    months.add("January");
        months.add("February");
        months.add("March");
        months.add("April");
        months.add("May");
        months.add("June");
        months.add("July");
        months.add("August");
        months.add("September");
        months.add("October");
        months.add("November");
        months.add("December");
        for(day = 1;day < 32; day++){
            days.add(day);
        }
        for(year = 2023;year <= 2100; year++){
            years.add(year);
        }
        binding = Activity3Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main3);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main3);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}